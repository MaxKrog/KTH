a = magic(10);

b = patchImage(a, 3, 3)
