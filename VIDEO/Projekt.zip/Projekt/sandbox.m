a = zeros(4,4,200);

for i = 1: length(a)
    a(:,:,i) = i;
end
b = reshape(a, 4, []);
c = reshape(b, 16, []);

%b = mat2cell(a, [4 4], [20 10]);

